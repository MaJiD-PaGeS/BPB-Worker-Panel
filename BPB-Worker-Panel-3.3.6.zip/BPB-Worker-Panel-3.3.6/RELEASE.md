# ⚙️ Bug fixes and Improvements

- Added second WorkerLess config with Google DoH for circumstances which Cloudflare is blocked.
- Fixed Xray Fake DNS
- Updated Wizard tutorial.
